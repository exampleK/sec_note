<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;


class TestController extends Controller
{

    public function actionTest($name){
        // $name = Yii::$app->request->get('unserialize');
        return unserialize(base64_decode($name));
    }
}