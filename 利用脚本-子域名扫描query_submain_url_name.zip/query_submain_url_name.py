from io import open_code
from urllib import request
import io,sys,re,time
sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='gb18030')
import os
import time
import subprocess
from urllib.error import URLError
from urllib.request import ProxyHandler,build_opener
import urllib.request
import ssl
import requests
import json
ssl._create_default_https_context = ssl._create_unverified_context

class Spider():
    url_par=''
    url='https://securitytrails.com/list/apex_domain/%s'%(url_par)
    # str_ip_port_pattern = re.compile(r'^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\:([0-9]|[1-9]\d{1,3}|[1-5]\d{4}|6[0-5]{2}[0-3][0-5])')
    ip_port_pattern = 'window.csrf_token = "([\s\S]*?)"'
    domain_name_pattern = '"hostname":"([\s\S]*?)",'
    total_page_pattern = '"total_pages":([\s\S]*?)}'
    # current_page_pattern =
    page = 1
    token='null'
    # ip_port_pattern = '/dns">([\s\S]*?)</a>'
    #    window.csrf_token = "
    # ip_port_pattern = '<td>([\s\S]*?)</td>'
    #main_one_pattern = ''

    def fetch_content(self):
        headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.62 Safari/537.36'}
        
        r = urllib.request.Request(url=Spider.url,headers=headers)#这里要注意，必须使用url=url，headers=headers的格式，否则回报错，无法连接字符
    
        # re = request.urlopen(Spider.url)
        rp=urllib.request.urlopen(r) #测试ip的网址
        htmls = rp.read().decode('utf-8')
        # print(htmls)
        return htmls

    def post_data():
        # data={}
        # headers={}
        data= {"_csrf_token":"%s"%(Spider.token)}
        print(data)
        headers = {
        'Host': 'securitytrails.com',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',
        'Content-Type': 'application/json;charset=UTF-8',
        'Cookie': '_securitytrails_app=QTEyOEdDTQ.tsvN4pV_txz7EI5N3wDXJ0o7TiFlORCSgE5bmUKXrTpVQgxZqC161Q0My18.AIbf7A1tHkFNmeja.DgD2wyGqPMAFskgFMdd7d9tuJShb0iOWu9iRWrdITXIi82nGfd0Ss3HGd-1JbQEbY9iE6OfsgPW-1OF4X2WCJuTMHinsLLWQJDDHdUI7gdX2CRDpq0sg3l4tcj_lXQDBGCeznw5kLzodd1FwpwfsnJr3xxHsrdon7Q84a2UyAVQU5z9TcJh02pgrBgafc2wUzbvQv0KwlkTw9vyJsZ4zWPm89EMwG_IbQV68j2i0ogfiGvDY5BxRXDKI.yuhYREMzTXa9Y3LlaK1Vzw'
        }
        r2 = requests.post("https://securitytrails.com/app/api/v1/list_new/hostname/%s"%(Spider.url_par),data=json.dumps(data), headers=headers)
        # print(type(json.dumps(data)))
        # print(r2.text)
        # --
        # 抓取一共几页，然后for循环抓取写进txt
        # --
        two_html = re.findall(Spider.total_page_pattern,r2.text)
        for i in two_html:
            Spider.page=int(i)
            # print(Spider.page)

        with open('domain_name%s.txt'%(time.strftime("%Y%m%d%H%M%S", time.localtime())), 'w') as f:
            for ii in range(1,Spider.page+1,1):
                print(ii)
                # Spider.post_request(i)
                # r2.text
                print(Spider.post_request(ii))
                for_html = re.findall(Spider.domain_name_pattern,Spider.post_request(ii))
                # print("total:",len(two_html))
                for iii in for_html:
                    f.write(iii+'\n')

    def post_request(page):
        # data={}
        # headers={}
        data= {"_csrf_token":"%s"%(Spider.token)}
        headers = {
        'Host': 'securitytrails.com',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',
        'Content-Type': 'application/json;charset=UTF-8',
        'Cookie': '_securitytrails_app=QTEyOEdDTQ.tsvN4pV_txz7EI5N3wDXJ0o7TiFlORCSgE5bmUKXrTpVQgxZqC161Q0My18.AIbf7A1tHkFNmeja.DgD2wyGqPMAFskgFMdd7d9tuJShb0iOWu9iRWrdITXIi82nGfd0Ss3HGd-1JbQEbY9iE6OfsgPW-1OF4X2WCJuTMHinsLLWQJDDHdUI7gdX2CRDpq0sg3l4tcj_lXQDBGCeznw5kLzodd1FwpwfsnJr3xxHsrdon7Q84a2UyAVQU5z9TcJh02pgrBgafc2wUzbvQv0KwlkTw9vyJsZ4zWPm89EMwG_IbQV68j2i0ogfiGvDY5BxRXDKI.yuhYREMzTXa9Y3LlaK1Vzw'
        }

        print("https://securitytrails.com/app/api/v1/list_new/hostname/%s?page=%s"%(Spider.url_par,page))
        r = requests.post("https://securitytrails.com/app/api/v1/list_new/hostname/%s?page=%s"%(Spider.url_par,page),data=json.dumps(data), headers=headers)
        return r.text

    def analysis(self,htmls):
        # one_html = re.findall(Spider.tr_ip_port_pattern,htmls)
        # print(one_html)
        one_html = re.findall(Spider.ip_port_pattern,htmls)

        # print(one_html)
        # token = ''
        for i in one_html:
            Spider.token=i

        # return token

    def main(self):
        # htmls = self.fetch_content()
        # self.analysis(htmls)
        # print(Spider.token)
        Spider.post_data()
        # step 2
        # 跳到post_data()方法

if __name__ == '__main__':
    Spider.url_par = str(input("Input query submain name url:"))
    # step 1
    # 输入子域名
    # 例如 xxx.com
    spider = Spider()
    spider.main()